# PixelPlay

A small, static neon arcade website with four original mini-games:
- Neon Dodge
- Memory Match
- Click Rush
- Number Slide

No build tools, server-side code, account system, analytics, or external game embeds are required.

## Run it on your computer
Open `index.html` in Chrome or another modern browser.

## Publish it for free with GitHub Pages
1. Sign in or create an account at https://github.com/
2. Create a new **public** repository named `pixelplay` (or `<your-username>.github.io` if you want the root Pages address).
3. Upload `index.html` to the repository root and commit the change.
4. Open the repository's **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/(root)`, then Save.
7. Wait for the Pages deployment to finish. The site URL will usually be:
   `https://<your-username>.github.io/pixelplay/`
   If you named the repository `<your-username>.github.io`, it will usually be:
   `https://<your-username>.github.io/`

GitHub Pages availability and UI labels may change. Check the official documentation: https://docs.github.com/pages

## Notes
- This is a static front-end project. It does not include a custom domain.
- The GitHub Pages URL depends on your GitHub username and repository name; it cannot be reserved or verified from this package.
- The site is designed for modern browsers, including many school Chromebooks, but a school's device/network policies still apply.
